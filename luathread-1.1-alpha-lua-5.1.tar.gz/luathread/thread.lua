local thread = require"thread.core"
module("thread")

